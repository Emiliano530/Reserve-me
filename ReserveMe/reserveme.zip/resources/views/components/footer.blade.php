<div
    class="w-screen flex items-center justify-center text-white bg-black border-gray-800">
    <div class="flex p-5 gap-1 justify-center flex-col">
        <label for="" class="text-xl">Contactanos:</label>
        <div class="flex gap-1 justify-center">
            <a href="https://www.facebook.com/dajohucoffe">
                <x-facebook-logo/>
            </a>
            <a href="https://www.instagram.com/dajohucoffe/">
                <x-instagram-logo/>
            </a>
        </div>
    </div>
</div
