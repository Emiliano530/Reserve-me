<input type="checkbox" {!! $attributes->merge(['class' => 'rounded-full bg-gray-200 border-gray-700 text-indigo-600 shadow-md focus:ring-indigo-600 focus:ring-offset-white']) !!}>
