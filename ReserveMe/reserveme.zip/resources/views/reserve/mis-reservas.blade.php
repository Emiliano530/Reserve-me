<x-app-layout>
    @livewire('reservas')
</x-app-layout>