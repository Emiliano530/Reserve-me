<x-app-layout>
    @livewire('recomendations')
</x-app-layout>