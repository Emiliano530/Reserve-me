<?php

namespace App\Filament\Widgets;

use App\Models\Reservation;
use Carbon\Carbon;
use Filament\Widgets\PieChartWidget;

class ReservationsChart extends PieChartWidget
{
    protected static ?string $heading = 'Reservations Chart';

    protected function getData(): array
    {
        $reservations = Reservation::where('reservation_status', 'Completada')->get();

        $data = [];

        foreach ($reservations as $reservation) {
            $reservationDate = Carbon::parse($reservation->reservation_datetime);
            $month = $reservationDate->format('F');
            $day = $reservationDate->format('d');

            if (isset($data[$month][$day])) {
                $data[$month][$day]++;
            } else {
                $data[$month][$day] = 1;
            }
        }

        return $data;
    }
}
