<?php return array (
  'fast-booking' => 'App\\Http\\Livewire\\FastBooking',
  'filter' => 'App\\Http\\Livewire\\Filter',
  'menu' => 'App\\Http\\Livewire\\Menu',
  'navbar' => 'App\\Http\\Livewire\\Navbar',
  'recomendations' => 'App\\Http\\Livewire\\Recomendations',
  'reservas' => 'App\\Http\\Livewire\\Reservas',
  'table-data' => 'App\\Http\\Livewire\\TableData',
  'update-profile' => 'App\\Http\\Livewire\\UpdateProfile',
  'welcome' => 'App\\Http\\Livewire\\Welcome',
);