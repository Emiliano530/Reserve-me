<x-app-layout>
    @livewire('table-data', ['mesaId' => $mesaId])
</x-app-layout>