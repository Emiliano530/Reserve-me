<x-app-layout>
    @livewire('filter')
 </x-app-layout>