<x-app-layout>
   @livewire('menu')
</x-app-layout>