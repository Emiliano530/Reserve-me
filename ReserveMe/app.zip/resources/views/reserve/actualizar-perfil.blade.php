<x-app-layout>
    @livewire('update-profile')
</x-app-layout>
