<svg class=" group w-12 h-12 stroke-5 stroke-white" width="50" height="50" xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 50 50">
    <g id="Layer_1">
        <title>Layer 1</title>
        <g stroke-width="3">
            <g id="svg_4" />
            <g stroke-linejoin="round" stroke-linecap="round" id="svg_3" />
            <g id="svg_2">
                <path class="group-hover:fill-blue-800" stroke-miterlimit="10" stroke-linejoin="round"
                    stroke-linecap="round" fill="none"
                    d="m35.45833,48.16595l-21.29167,0c-6.69167,0 -12.16667,-5.55395 -12.16667,-12.34211l0,-21.59868c0,-6.78816 5.475,-12.34211 12.16667,-12.34211l21.29167,0c6.69167,0 12.16667,5.55395 12.16667,12.34211l0,21.59868c0,6.78816 -5.475,12.34211 -12.16667,12.34211z"
                    class="st0" />
                <path class="group-hover:fill-white group-hover:stroke-none" stroke-miterlimit="10"
                    stroke-linejoin="round" stroke-linecap="round"
                    d="m40.02083,25.02451l-7.60417,0l0,-4.31974c0,-1.07993 0.76042,-1.85132 1.825,-1.85132l4.25833,0l0,-7.71382l-6.08333,0l0,0c-4.25833,0 -7.60417,3.39408 -7.60417,7.71382l0,0l0,6.17105l-6.08333,0l0,7.71382l6.08333,0l0,15.42763l7.60417,0l0,-15.42763l4.5625,0l3.04167,-7.71382z"
                    class="st0" />
            </g>
        </g>
    </g>

</svg>
